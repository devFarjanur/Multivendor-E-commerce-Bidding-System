<h4>Admin Login Credintial</h4>
<h4>email: admin@gmail.com</h4>
<h4>password: 123456789</h4>
<h4>Go To <a href="{{ route('admin.login') }}">Admin Login</a></h4>
<h4><a href="{{ route('admin.dashboard') }}">Admin Dashboard</a></h4>

<br>
<br>

<h4>Vendor Login Credintial</h4>
<h4>email: vendor@gmail.com</h4>
<h4>password: 123456789</h4>
<h4>Go To <a href="{{ route('vendor.login') }}">Vendor Login</a></h4>
<h4><a href="{{ route('vendor.dashboard') }}">Vendor Dashboard</a></h4>
